function inBodies
    include_global

B1 = Body_struct;
B1.r = [0.5840; 0.3586];
B1.p = 6.0819;
B1.m = 20;
B1.J = 2.5;

Bodies = [B1];
