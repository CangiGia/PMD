function inJoints
    include_global

Joints = [ ];
