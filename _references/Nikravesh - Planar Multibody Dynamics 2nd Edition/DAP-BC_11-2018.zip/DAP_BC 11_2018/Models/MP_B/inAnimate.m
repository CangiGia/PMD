function inAnimate
    include_global
    
Points_anim = [];

% Variables for defining the 3D animation axes used by plot_sys

xmin = -0.1; xmax =  0.9;
ymin = 0; ymax =  1.0;
