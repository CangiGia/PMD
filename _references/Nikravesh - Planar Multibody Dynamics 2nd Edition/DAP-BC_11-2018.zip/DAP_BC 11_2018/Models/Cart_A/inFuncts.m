function inFuncts
    include_global

F1 = Funct_struct;
F1.type = 'a';
F1.coeff = [0 -2*pi 0];

Functs = [F1];
