function inForces
    include_global

F1 = Force_struct;
F1.type = 'weight';  % include the weight

Forces = [F1];
