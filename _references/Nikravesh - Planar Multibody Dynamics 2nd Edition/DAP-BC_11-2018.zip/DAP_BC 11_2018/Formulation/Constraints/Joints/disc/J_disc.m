% disc_J
% Jacobian sub-matrices for a disk joint between a body and the ground

    Di = [ 0  1  0
           1  0  Joints(Ji).R];
