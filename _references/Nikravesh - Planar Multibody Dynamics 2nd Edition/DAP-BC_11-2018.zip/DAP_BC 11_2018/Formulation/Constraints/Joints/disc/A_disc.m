% disc_A
% The r-h-s of acc. constraints for a disk joint

    f = [0; 0];
