% rel-rot_J
% Jacobian sub-matrices for relative-rotational constraint 

    Di = [0 0  1];
    Dj = [0 0 -1];
