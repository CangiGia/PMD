function s_r = s_rot(s)
% This function rotates a vector 90 degrees positively
    s_r = [-s(2); s(1)];
    