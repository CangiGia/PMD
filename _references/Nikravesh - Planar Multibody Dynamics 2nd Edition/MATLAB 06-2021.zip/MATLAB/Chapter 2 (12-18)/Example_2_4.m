% Example 2.4
% Define matrices A and B
    A = [1 2 3; 4 5 6]
    B = [7 8 9; -1 -2 -3]
% Compute the sum of A and B
    C = A + B
% Compute the product A*B'
    D = A*B'