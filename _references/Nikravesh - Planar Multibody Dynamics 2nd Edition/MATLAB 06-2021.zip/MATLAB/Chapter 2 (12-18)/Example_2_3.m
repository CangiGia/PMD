% Example 2.3
% Define vectors a and b
    a = [2 3]'; b = [4 5]';
% Compute the magnitude of the cross producsts a x b and b x a
    c = s_rot(a)'*b
    d = s_rot(b)'*a