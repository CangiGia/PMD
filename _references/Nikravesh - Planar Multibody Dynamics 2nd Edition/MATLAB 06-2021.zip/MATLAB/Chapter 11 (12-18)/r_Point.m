function r_P = r_Point(r, s_P)
% This function computes the x-y coordinates of point P
    r_P = r + s_P;
end
