function inConst
    include_global

    nConst = 3;
end