function inAnimate
    include_global
    

Points_anim = [];

% Variables for defining the 3D animation axes used by plot_sys

xmin = -2; xmax =  2;
ymin = -0.5; ymax =  3.5;
