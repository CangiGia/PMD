function inConst
    include_global

    nConst = 0;
end