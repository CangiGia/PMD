function inConst
    include_global

    nConst = 2;
end