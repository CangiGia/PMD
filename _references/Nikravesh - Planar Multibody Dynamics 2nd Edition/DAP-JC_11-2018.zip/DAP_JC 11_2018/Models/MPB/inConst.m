function inConst
    include_global

    nConst = 1;
end