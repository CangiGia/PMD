function inAnimate
    include_global

    Points_anim = [];

    Bodies(1).color = 'r';


% Parameters for defining animation/plot axes 
    xmin = -1; xmax =  2.5;
    ymin = -0.2; ymax =  2.8;
