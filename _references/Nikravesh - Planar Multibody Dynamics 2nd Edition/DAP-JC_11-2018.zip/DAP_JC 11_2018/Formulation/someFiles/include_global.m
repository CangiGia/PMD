% include_global
global Bodies nB nB3 nB6      
global Points nP Points_anim nPanim nPtot
global Uvectors nU 
global Forces nF
global nJC nJC2 nConst
global M_array M_inv_array
global Functs nFc
global Bmat Bd C Phi rhsV rhsA
global ZZ redund
global num Lambda 
global xmin xmax ymin ymax
global showtime t10
global flags pen_d0